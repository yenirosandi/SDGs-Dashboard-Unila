<link href="{{asset('frontend/mosh/style.css')}}" rel="stylesheet">

  <footer class="sticky-footer bg-white">
      <div class="container">
        <div class="copyrights">
              <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  <b style="color:#FC8213;"> Dashboard SDGs</b>. All Rights Reserved |
              </a>SDGs Center<a style="color:#68ae00;"> <a href="https://www.unila.ac.id/" target="_blank"> Universitas Lampung </p>
            </div>
      </div>
    </footer>
