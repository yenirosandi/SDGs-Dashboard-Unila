<?php $__env->startSection('title', 'Dashboard SDGs Unila'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title_breadcrumb','Home'); ?>	


SUSTAINABLE DEVELOPMENT GOALS <hr>
      <!-- ***** Preloader Start ***** -->
      <div id="preloader">
        <div class="mosh-preloader"></div>
    </div>

    <!-- ***** Portfolio Area Start ***** -->
    <section class="mosh-portfolio-area section_padding_100_0 clearfix">
        <div class="container">
            <div class="row">
                <!-- <div class="col-12">
                    <div class="section-heading text-center">

                    </div>
                </div> -->
            </div>
        </div>

        <div class="mosh-portfolio">
            <!-- Single gallery Item Start -->
            <?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
            <div class="single_gallery_item gd">
            <a href="<?php echo e(url('goalDetail', $goal->id_goal)); ?>"  class="btn btn-sm btn-outline-secondary ">
             <img src="<?php echo e($goal->gambar); ?>" alt="">
             </a>     
            <!-- <div class="gallery-hover-overlay d-flex align-items-center justify-content-center">
                    <div class="port-hover-text text-center">
                    <a href="<?php echo e(url('goalDetail', $goal->id_goal)); ?>"  class="btn btn-sm btn-outline-secondary">
 
                        <h4>"<?php echo e($goal->id_goal); ?>"</h4>
                        <a href="#">Goal 3</a>
                          </a>     
        
                </div>
                </div> -->
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h3>Nothing</h3>
            <?php endif; ?>
           

        </div>
    </section>
    <!-- ***** Portfolio Area End ***** -->

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/frontend/home.blade.php ENDPATH**/ ?>