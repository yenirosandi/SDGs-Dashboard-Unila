<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="">

    <link rel="icon" href="<?php echo e(asset('frontend/gambar/sdgs.png')); ?>">

    <title><?php echo $__env->yieldContent('title','Master Page'); ?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template
    <link href="<?php echo e(asset('dist/css/album.css')); ?>" rel="stylesheet"> -->

    <!-- Core Stylesheet -->
    <link href="<?php echo e(asset('frontend/mosh/style.css')); ?>" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="<?php echo e(asset('frontend/mosh/css/responsive.css')); ?>" rel="stylesheet">
  </head>

<body>

   
      <?php echo $__env->make('frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> <?php echo e(date('d M Y')); ?> / <?php echo $__env->yieldContent('title_breadcrumb'); ?>
            </li>
        </ol>
        <main role="main" style="background-color:#D3D3D3; padding: 40px;">

        <div class="container" style=" border-radius: 30px; padding: 50px 50px 50px 50px; background: #FFFFFF;   box-shadow: 5px 10px 18px #888888;">

   <!-- <div class="container"> -->
      <?php echo $__env->yieldContent('content'); ?>

      <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="<?php echo e(asset('dist/js/vendor/jquery-slim.min.js')); ?>"><\/script>')</script>
    <script src="<?php echo e(asset('dist/js/vendor/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/vendor/holder.min.js')); ?>"></script> -->


    <!-- MOSH TEMPLT -->
        <!-- jQuery-2.2.4 js -->
    <script src="<?php echo e(asset('frontend/mosh/js/jquery-2.2.4.min.js')); ?>"></script>
    <!-- Popper js -->
    <script src="<?php echo e(asset('frontend/mosh/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('frontend/mosh/js/bootstrap.min.js')); ?>"></script>
    <!-- All Plugins js -->
    <script src="<?php echo e(asset('frontend/mosh/js/plugins.js')); ?>"></script>
    <!-- Active js -->
    <script src="<?php echo e(asset('frontend/mosh/js/active.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/frontend/master.blade.php ENDPATH**/ ?>