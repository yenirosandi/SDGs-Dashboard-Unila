<?php $__currentLoopData = $goal_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $__env->startSection('title'); ?>
    SDG <?php echo $goal->id_goal; ?>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('title_breadcrumb'); ?>
  / SDGs <?php echo $goal->id_goal; ?>

  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data SDG <?php echo $goal->id_goal; ?></h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <h5 style="color:#323236;">Sustainable Development Goals</h5>
        <hr>
          <div class="row">
            <div class="col-md-3 col-xs-12">
                <div class-"thumbnail">
                  <img src="/<?php echo e($goal->gambar); ?>" style="width:225px; height:225px;"class="card-img">
                </div>
            </div>
            <div class="col-md-8 col-md-offset-1">
              <div class="col-md-10 col-md-offset-1">
                  <h2 style="color:black;"><?php echo ucwords($goal->nama_goal); ?>
                    </a> </h2>
                  <p style="text-align:justify; color:black"><?php echo e($goal->deskripsi_goal); ?> </p>
              </div>
            </div>
          </div>
        <br><br><br>
        <h5 style="color:#323236;">Tabel Pencapaian</h5>
        <hr>
        <!-- <div class="container"> -->

        <form action="<?php echo e(route('goaldetail.search', $goal->id_goal )); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                    &nbsp;&nbsp;&nbsp;<label for="from" class="col-form-label">Dari</label>
                        <div class="col-md-3">
                            <select id="from" class="form-control"name="from" required>
                                      <option value="" >Pilih tahun</option>
                                        <?php
                                        $thn_skr=  date('Y');
                                        for ($tahun = $thn_skr; $tahun >= 2017; $tahun--) {
                                        ?>
                                        <option type="number"value="<?php echo e($tahun); ?>"><?php echo $tahun ?></option>
                                      <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                           <!-- <button type="submit" class="btn btn-primary btn-sm" name="search" >Cari</button> -->
                            <button type="submit" class="btn btn-info btn-sm" name="exportPDF">Unduh PDF</button>
                        </div>

                    </div>
               
        </form>
        <!-- </div> -->
        <label  style="margin-top:10px; font-size:12px; "> *Data dalam rentang waktu 5 tahun (Jika sudah diinputkan) </label>
        <br><br>
        
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">No.</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Indikator</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Sumber Data</th>
                <th style="text-align:center; vertical-align:middle;" colspan="2" rowspan="2">Baseline (2017)</th>
                <th style="text-align:center; vertical-align:middle;" colspan="<?php echo e($kolomtahun); ?>">Realisasi Pencapaian</th>
              </tr>
              <tr>
                <?php for($thn=2018; $thn <= $tahun_now; $thn++): ?>
                  <th colspan="2" style="text-align:center; vertical-align:middle;" ><?php echo e($thn); ?></th>
                <?php endfor; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <!-- <td style="text-align:center; vertical-align:middle;" colspan="6" disable>Belum ada data</td> -->
                  <?php if($data_sub->indikator->indikator!=$indikator): ?>
                    <th style="background-color:#e8f1ff;" colspan="<?php echo e($kolomindi); ?>"><?php echo e($data_sub->indikator->indikator); ?><a href="<?php echo e(route('grafikIndi', $data_sub->indikator->id_indikator )); ?>"> (Grafik <span style="width:30px; height:30px"><img src="<?php echo e(url('img/statistics.png')); ?>" style="width:1.5%;" alt="">)</span></a></th>
                  <?php endif; ?>
                <?php $indikator=$data_sub->indikator->indikator; ?>
              </tr>
              <tr>
                <?php if($data_sub->subindikator!=$subindi): ?>
                  <td style='text-align:center;border-bottom:none;border-right:none;'><?php echo e($no); ?>.</td>
                  <?php $no++; ?>
                  <td style='border-left:none; border-bottom:none;'><?php echo e($data_sub->subindikator); ?></td>
                <?php else: ?> <td style="border-bottom:none;border-top:none" colspan="2"></td>
                <?php endif; ?>
                <?php $subindi=$data_sub->subindikator; ?>

                <?php if($data_sub->fk_id_indikator==$data_sub->indikator->id_indikator): ?>
                  <td><?php echo e($data_sub->fsumberdata->sumberdata); ?></td>
                <?php endif; ?>
                <!-- <style>
                  td:empty{border-bottom:none;border-top:none} /* style css3 untuk kolom kosong */
                </style> -->

                <!-- Buat nilai pencapaian -->
                <?php $__currentLoopData = $dcapai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $tahun=2017; ?>
                  <?php while($tahun<=$tahun_now): ?>
                    <?php if($tahun==$capai->tahun && $data_sub->id_m_subindikator==$capai->fk_id_m_subindikator): ?>
                      <td style="text-align:center;"><?php echo e($capai->nilai); ?></td>
                      <td>
                        <center>
                          <?php echo $capai->trend->simbol_trend; ?>

                        </center>
                      </td>
                    <?php else: ?>
                    <?php endif; ?>
                    <?php $tahun++ ?>
                  <?php endwhile; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>



            </tbody>
          </table>
        </div>
        <hr>
      </div>
    </div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/goal_detail.blade.php ENDPATH**/ ?>