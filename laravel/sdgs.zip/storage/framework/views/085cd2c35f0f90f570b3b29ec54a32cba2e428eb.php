<?php $__currentLoopData = $goal_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $__env->startSection('title'); ?>
    SDG <?php echo $goal->id_goal; ?>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('Judul'); ?>
    SDGs <?php echo $goal->id_goal; ?>:<?php echo $goal->nama_goal; ?>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('title_breadcrumb'); ?>
  SDGs <?php echo $goal->id_goal; ?>


  <?php $__env->stopSection(); ?>

    <!-- <?php $__env->startSection('Judul','SDGs <?php echo e($goal->id_goal); ?>:<?php echo e($goal->nama_goal); ?>'); ?> -->
  <?php $__env->startSection('JudulDesc'); ?>
    <?php echo $goal->deskripsi_goal; ?>

  <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Form Master Indikator SDG <?php echo $goal->id_goal; ?></h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <h4>Grafik</h4>
        <hr>

          <div class="row">


              <img width="300px" height ="300px" src="/<?php echo e($goal->gambar); ?>">
          </div>


        <br><br><br>
        <h4>Tabel</h4>
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">No.</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Indikator</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Sumber Data</th>
                <th style="text-align:center; vertical-align:middle;" colspan="2" rowspan="2">Baseline (2017)</th>
                <th style="text-align:center; vertical-align:middle;" colspan="<?php echo e($kolomtahun); ?>">Realisasi Pencapaian</th>
              </tr>
              <tr>
                <?php for($thn=2018; $thn <= $tahun_now; $thn++): ?>
                  <th colspan="2" style="text-align:center; vertical-align:middle;" ><?php echo e($thn); ?></th>
                <?php endfor; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <!-- <td style="text-align:center; vertical-align:middle;" colspan="6" disable>Belum ada data</td> -->
                  <?php if($data_sub->indikator!=$indikator): ?>
                    <th style="background-color:#e8f1ff; " colspan="<?php echo e($kolomindi); ?>"><?php echo e($data_sub->indikator); ?><a href="<?php echo e(route('grafikIndi', $data_sub->id_indikator )); ?>"> <span style="background-color:cadetblue  ;width:30px; height:30px"><img src="<?php echo e(url('img/profits.png')); ?>" style="width:30px; height:30px" alt=""></span></a></th>
                  <?php endif; ?>
                <?php $indikator=$data_sub->indikator; ?>
              </tr>
              <tr>
                <?php if($data_sub->subindikator!=$subindi): ?>
                  <td><?php echo e($no); ?></td>
                  <?php $no++; ?>

                  <td><?php echo e($data_sub->subindikator); ?></td>
                <?php else: ?><td style="background-color:#f5f5f5;" colspan="2"></td>
                <?php endif; ?>
                <?php $subindi=$data_sub->subindikator; ?>

                <?php if($data_sub->fk_id_indikator==$data_sub->id_indikator): ?>
                  <td><?php echo e($data_sub->sumberdata); ?></td>
                <?php endif; ?>
                <!-- Buat nilai pencapaian -->


                <style>
                  td:empty{background:grey;} /* style css3 untuk kolom kosong */
                </style>


                <?php $__currentLoopData = $data_capai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php $tahun=2017; ?>
                  <?php while($tahun<=$tahun_now): ?>
                    <?php if($tahun==$capai->tahun && $data_sub->id_m_subindikator==$capai->fk_id_m_subindikator): ?>
                      <td><?php echo e($capai->nilai); ?></td>
                      <td>
                        <center>
                          <?php echo $capai->simbol_trend; ?>

                        </center>
                      </td>
                    <?php else: ?>


                    <?php endif; ?>
                    <?php $tahun++ ?>
                  <?php endwhile; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>



            </tbody>
          </table>
        </div>
        <hr>
      </div>
    </div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/goal_detail.blade.php ENDPATH**/ ?>