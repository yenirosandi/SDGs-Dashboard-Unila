<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cetak Detail Goal <?php echo e($id); ?></title>
    <style type="text/css">
      table tr td,
      table tr th{
        font-size: 14px;
        padding: 7px;
      }
    </style>

  </head>
  <body>
    <img src="<?php echo e(public_path('img/logo_sdgsunila.png')); ?>" width="15%">
    <br>
    <h4>LAPORAN PENCAPAIAN SUSTAINABLE DEVELOPMENT GOAL <?php echo e($id); ?></h4>
    <hr style="border:1px solid black;">
    <table border ="0" cellpadding="2";>
      <tr>
        <?php  ?>
        <td><img src="<?php echo e($goalTbl->gambar); ?>" style="width:20%;"></td>
        <td>
          <h3><?php echo e($goalTbl->nama_goal); ?></h3>
          <p style="text-align:justify; color:black; font-size: 16px"><?php echo e($goalTbl->deskripsi_goal); ?> </p>
        </td>
      </tr>
    </table>
    <br><br>

    <table class="table table-bordered" border="1" width="100%" cellspacing="0">
      <thead>
        <tr>
          <th style="text-align:center; vertical-align:middle;" rowspan="2">No.</th>
          <th style="text-align:center; vertical-align:middle;" rowspan="2">Indikator</th>
          <th style="text-align:center; vertical-align:middle;" rowspan="2">Sumber Data</th>
          <th style="text-align:center; vertical-align:middle;" colspan="2" rowspan="2">Baseline (<?php echo e($from); ?>)</th>
          <th style="text-align:center; vertical-align:middle;" colspan="<?php echo e($kolomtahunPdf); ?>">Realisasi Pencapaian</th>
        </tr>
        <tr>
          <?php for($thn=$from+1; $thn <= $TahunMax; $thn++): ?>
            <th colspan="2" style="text-align:center; vertical-align:middle;" ><?php echo e($thn); ?></th>
          <?php endfor; ?>
        </tr>
      </thead>
      <tbody>
        <!-- Kalo ga ada isi -->
        <?php if($countCapai==0): ?>
        <tr>
          <td bgcolor="#f0f0f0"colspan="5" align="center">Tidak ada Data</td>
        </tr>
        <?php endif; ?>
        <?php $indikator=null; $subindi=null; ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <!-- <td style="text-align:center; vertical-align:middle;" colspan="6" disable>Belum ada data</td> -->

            <?php if($data_sub->indikator!=$indikator): ?>
              <td style="background-color:#e8f1ff;" colspan="<?php echo e($kolomindiPdf); ?>"><?php echo e($data_sub->indikator); ?></td>
            <?php else: ?> <td style="padding: 0px; border:0px;" colspan="<?php echo e($kolomindiPdf); ?>"></td>
            <?php endif; ?>
          <?php $indikator=$data_sub->indikator; ?>
        </tr>
        <tr>
          <?php if($data_sub->subindikator!=$subindi): ?>
            <td style='text-align:center;border-bottom:none;'><?php echo e($no); ?>.</td>
            <?php $no++; ?>
            <td style="border-bottom:none;"><?php echo e($data_sub->subindikator); ?></td>
          <?php else: ?>
          <td style='text-align:center;border-top:none; border-bottom:none;'></td>
          <td style="border-top:none; border-bottom:none;"></td>
          <?php endif; ?>
          <?php $subindi=$data_sub->subindikator; ?>

          <?php if($data_sub->fk_id_indikator==$data_sub->id_indikator): ?>
            <td style="border-bottom:none;"><?php echo e($data_sub->sumberdata); ?></td>
          <?php endif; ?>

          <!-- Buat nilai pencapaian -->
          <?php $__currentLoopData = $data_capai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $tahun=2017;
            // DD($trend);
            ?>
            <?php while($tahun<=$to): ?>
              <?php if($tahun==$capai->tahun && $data_sub->id_m_subindikator==$capai->fk_id_m_subindikator): ?>
                <td style="text-align:center; border-right:none;"><?php echo e($capai->nilai); ?></td>
                <?php
                $trend= $capai->keterangan_trend;
                // DD($trend);
                //ubah data simbol trend
                if ($trend=='Data Naik') {
                  $ikonTrend='trend_up.png';
                }elseif ($trend=='Data Konstan') {
                  $ikonTrend='trend_right.png';
                }elseif ($trend=='Data Turun') {
                  $ikonTrend='trend_down.png';
                }elseif ($trend=='Tidak Ada Data') {
                  $ikonTrend='trend not yet.png';
                }else
                $ikonTrend='trend not yet.png';
                 ?>
                <td style="border-left:none;">
                  <center>
                    <!-- <?php echo $capai->simbol_trend; ?> -->
                    <img src="<?php echo e(public_path('img/'.$ikonTrend)); ?>" width="80%">
                  </center>
                </td>
              <?php else: ?>
              <?php endif; ?>
              <?php $tahun++ ?>
            <?php endwhile; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>

        </tbody>
      </table>





  </body>
</html>
<?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\layout\pdfDetailGoal.blade.php ENDPATH**/ ?>