<?php $__env->startSection('title','Edit Master Indikator SDGs'); ?>
<?php $__env->startSection('Judul','Edit Master Indikator'); ?>
<?php $__env->startSection('JudulDesc','Ini adalah halaman edit master indikator dimana terdapat form untuk memperbarui data master.'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb','Edit'); ?>

  <!-- Form -->
  <div class="card shadow mb-4 w-50">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Form Master Indikator</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">
          <form method="post" class="form-horizontal" action="<?php echo e(route('master_indikator.update',$master_indikator->id_indikator)); ?>">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('put')); ?>

            <div class="form-group">
              <label class="control-label col-sm-8" for="fk_id_goal">Goal ke:</label>
              <div class="col-sm-4">
                <select class="form-control" name="fk_id_goal">
                  <?php $__currentLoopData = $fk_id_goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  if($key!=0){
                      $indi_fk_goal=DB::table('t_goals')->select('id_goal', 'id_goal')->where('id_goal',$key)->get();
                      if(count($indi_fk_goal)>0){
                          foreach ($indi_fk_goal as $data){?>
                              <option value="<?php echo e($data->id_goal); ?>"<?php echo e($edit_id_goal->id_goal==$data->id_goal?' selected':''); ?>>SDG <?php echo e($data->id_goal); ?></option>
                      <?php }
                    }
                  }
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="indikator">Indikator:</label>
              <div class="col-sm-10">
                <input value="<?php echo e($master_indikator->indikator); ?>" name="indikator" type="text" class="form-control" required>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Ubah</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/master_indikator_edit.blade.php ENDPATH**/ ?>