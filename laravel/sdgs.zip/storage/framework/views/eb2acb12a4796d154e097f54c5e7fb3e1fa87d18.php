<?php $__env->startSection('title', 'Dashboard SDGs Unila'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title_breadcrumb',''); ?>
                <nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Home</a></li>
			</ol>
		</nav>

SUSTAINABLE DEVELOPMENT GOALS <hr>


<body>

        <div class="mosh-portfolio">

            <?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="single_gallery_item gd">

            <a href="<?php echo e(url('goalDetail', $goal->id_goal)); ?>"  class="btn btn-sm btn-outline-light ">
             <img src="<?php echo e($goal->gambar); ?>" alt="">
             </a>
            <!-- <div class="gallery-hover-overlay d-flex align-items-center justify-content-center">
                    <div class="port-hover-text text-center">
                    <a href="<?php echo e(url('goalDetail', $goal->id_goal)); ?>"  class="btn btn-sm btn-outline-secondary">

                        <h4>"<?php echo e($goal->id_goal); ?>"</h4>
                        <a href="#">Goal 3</a>
                          </a>

                </div>
                </div> -->

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h3>Nothing</h3>
            <?php endif; ?>
            <!-- <img src="<?php echo e(asset('img/sdgs/sds.png')); ?>" alt=""> -->

        </div>


</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\frontend\home.blade.php ENDPATH**/ ?>