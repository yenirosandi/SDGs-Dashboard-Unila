<?php $__env->startSection('title','Edit Profil'); ?>
<?php $__env->startSection('Judul','Edit Profil'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb'); ?>
/ <a href="<?php echo e(url()->previous()); ?>"> Profil </a>
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('title_breadcrumb2'); ?>
/ Edit Profil Admin
<?php $__env->stopSection(); ?>


<div class="card shadow mb-4 w-75">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Edit Profil</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">

                          <form class="" action="<?php echo e(route('profil.update', $user)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group">
                              <label class="control-label col-sm-8" for="nip">NIP:</label>
                              <div class="col-sm-10">
                                <input value="<?php echo e($user->nip); ?>" name="nip" type="text" class="form-control" required>
                              </div><br>

                              <label class="control-label col-sm-8" for="nama">Nama:</label>
                              <div class="col-sm-10">
                                <input value="<?php echo e($user->nama); ?>" name="nama" type="text" class="form-control" required>
                              </div><br>

                              <label class="control-label col-sm-8" for="username">Username:</label>
                              <div class="col-sm-10">
                                <input value="<?php echo e($user->username); ?>" name="username" type="text" class="form-control" required>
                              </div><br>

                              <label class="control-label col-sm-8" for="jabatan">Jabatan:</label>
                              <div class="col-sm-10">
                                <input value="<?php echo e($user->jabatan); ?>" name="jabatan" type="text" class="form-control" required>
                              </div><br>
                            </div>
                        
                            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Ubah</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/profil_edit.blade.php ENDPATH**/ ?>