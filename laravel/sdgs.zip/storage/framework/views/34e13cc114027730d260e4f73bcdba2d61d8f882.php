<?php $__env->startSection('title','Edit Sumber Data'); ?>
<?php $__env->startSection('Judul','Edit Sumber Data'); ?>
<?php $__env->startSection('JudulDesc','Ini adalah halaman edit sumber data dimana terdapat form untuk memperbarui data sumber data yang telah didaftarkan.'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb','Edit'); ?>

  <!-- Form -->
  <div class="card shadow mb-4 w-50">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Form Edit Sumber Data</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">
          <form method="POST" class="form-horizontal" action="<?php echo e(route('sumber_data.update',$sumber->id_m_sumberdata)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('put')); ?>

            <div class="form-group">
              <label class="control-label col-sm-8" for="sumberdata">Sumber Data:</label>
              <div class="col-sm-6">
                <input value="<?php echo e($sumber->sumberdata); ?>" name="sumberdata" type="text" class="form-control" id="sumberdata" required>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Ubah</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/sumber_data_edit.blade.php ENDPATH**/ ?>