<?php $__env->startSection('title_breadcrumb','/ Home'); ?>	
<?php $__env->startSection('title','Dashboard Admin'); ?>
<?php $__env->startSection('Judul','SDGs: Universitas Lampung'); ?>
<?php $__env->startSection('JudulDesc','Terdapat 11 SDGs yang harus diperhatikan dalam suatu universitas, diantaranya:'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="<?php echo e(url('admin/goalDetail', $goal->id_goal)); ?>">
     <img src="<?php echo e($goal->gambar); ?>" alt="" width="15%">
     </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>Nothing</h3>
    <?php endif; ?>
    <img src="<?php echo e(asset('img/sdgs/sds.PNG')); ?>" alt="SDGs" width="15%">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\admin\index.blade.php ENDPATH**/ ?>