<?php $__env->startSection('title','Pencapaian Indikator SDGs'); ?>
<?php $__env->startSection('Judul','Pencapaian Indikator'); ?>
<?php $__env->startSection('JudulDesc','Ini adalah halaman pencapaian indikator dimana admin dapat melihat, menambah, memperbarui, dan menghapus data Pencapaian.'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb','/ Pencapaian'); ?>



<!-- Form -->
<div class="card shadow mb-4 w-75">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Form Pencapaian Indikator</h6>
  </div>
  <div class="card-body">
    <div class="card-body">
      <div class="table-responsive">

      <!--  -->
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>


              <form method="POST" class="form-horizontal" action="<?php echo e(route('pencapaian_indikator.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                      <label class="control-label col-sm-8" for="tahun">Tahun:</label>
                      <div class="col-sm-4">
                            <select id="tahun" class="form-control"name="tahun">
                              <option value="">Pilih tahun</option>
                                <?php
                                for ($tahun = $thn_skr; $tahun >= 2017; $tahun--) {
                                ?>
                                <option type="number"value="<?php echo e($tahun); ?>"><?php echo $tahun ?></option>
                              <?php } ?>
                            </select>
                      </div><br>
                      <label class="control-label col-sm-10" for="goal">Goal ke:</label>
                      <div class="col-sm-10">
                            <select id="slgoal" class="form-control" name="goal" data-urlreq="<?php echo e(route('get.list.capaian.indikator')); ?>">
                              <!-- <option value="">Pilih goal</option> -->
                              <option value="" >Pilih Goal</option>
                              <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_goals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data_goals->id_goal); ?>">SDG <?php echo e($data_goals->id_goal); ?> - <?php echo e($data_goals->nama_goal); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                      </div><br>
                      <label class="control-label col-sm-8" for="indikator">Indikator master:</label>
                      <div class="col-sm-10">
                            <select id="slindi" class="form-control" name="indikator" data-urlreq="<?php echo e(route('get.list.capaian.subindi')); ?>">
                            <option value="">Pilih Indikator</option>
                            </select>
                      </div><br>
                      <label class="control-label col-sm-8" for="sub">Sub-indikator master:</label>
                      <div class="col-sm-10">
                            <select id="slsub" class="form-control" name="sub">
                              <option value="">Pilih Sub Indikator</option>
                            </select>
                      </div><br>
                      <div class="col-sm-12">
                          <div class="form-row">
                            <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                              <i class="fas fa-pencil-alt prefix"></i>
                              <label for="nilai">Nilai</label>
                              <textarea name="nilai" id="nilai" class="md-textarea form-control" rows="3" ><?php echo e(old('nilai')); ?></textarea>
                            </div>
                            <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                              <i class="fas fa-angle-double-right prefix"></i>
                              <label for="nilai_sebelumnya">Nilai Sebelumnya</label>
                              <h2 id="nilai_sebelumnya">0</h2>
                            </div>
                          </div>
                      </div><br>
                      <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                            <i class="fas fa-pencil-alt prefix"></i>
                            <label for="keterangan">Keterangan</label>
                            <textarea name="keterangan" id="keterangan" class="md-textarea form-control" rows="2" ><?php echo e(old('keterangan')); ?></textarea>
                      </div>
                      <label class="control-label col-sm-8" for="trend">Trend:</label>
                      <div class="col-sm-4">
                        <select class="form-control" name="trend">
                          <option value="">Pilih pencapaian</option>
                          <?php $__currentLoopData = $trends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_tren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data_tren->id_trend); ?>"><?php echo e($data_tren->keterangan); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div><br>
                </div>
            
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary">Tambahkan</button>
                  </div>
                </div>
              </form>
      </div>
    </div>
  </div>
</div>

<!-- Table -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Tabel Indikator</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No.</th>
            <th>Tahun</th>
            <th>Goal</th>
            <th>Indikator</th>
            <th>Sub Indikator</th>
            <th>Sumber Data</th>
            <th>Nilai</th>
            <th>Keterangan</th>
            <!-- <th>Berkas</th> -->
            <th>Trend</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $capai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no); ?><?php $no++; ?></td>
            <td><?php echo e($data->tahun); ?></td>
            <td>SDG <?php echo e($data->id_goal); ?></td>
            <td><?php echo e($data->indikator); ?></td>
            <td><?php echo e($data->subindikator); ?></td>
            <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($data->id_m_subindikator==$data_sub->id_m_subindikator): ?>
               <th><?php echo e($data_sub->sumberdata); ?></th>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($data->nilai); ?></th>
            <th><?php echo e($data->keterangan); ?></th>
            <!-- <th><?php echo e($data->berkas); ?></th> -->
            <th><?php echo e($data->keterangan_trend); ?></th>
            <th>
              <a href="<?php echo e(route('pencapaian_indikator.edit', $data->id_pencapaian)); ?>" class="btn btn-warning btn-circle btn-sm">
                <i class="fas fa-edit"></i>
              </a> Ubah
              <form id="data-<?php echo e($data->id_pencapaian); ?>" action="<?php echo e(route('pencapaian_indikator.destroy',$data->id_pencapaian)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

                </form>
                <button class="btn btn-danger btn-circle btn-sm delete-confirm" type="submit" onclick="deleteRow( <?php echo e($data->id_pencapaian); ?> )">
                    <i class="fas fa-trash"></i>
                  </button> Hapus
            </th>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\admin\pencapaian_indikator.blade.php ENDPATH**/ ?>