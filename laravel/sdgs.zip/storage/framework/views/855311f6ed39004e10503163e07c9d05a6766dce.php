<?php $__env->startSection('title','Master Indikator SDGs'); ?>
<?php $__env->startSection('Judul','Master Indikator'); ?>
<?php $__env->startSection('JudulDesc','Ini adalah halaman master indikator dimana admin dapat melihat, menambah, memperbarui, dan menghapus data master.'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb','/ Indikator'); ?>

  <!-- Form -->

  <?php if(session('success_message')): ?>
  <div class="alert alert-<?php echo e(Session::get('message_type')); ?>" id="waktu2" style="margin-top:10px;"><?php echo e(Session::get('message')); ?></div>
  <!-- <div class "alert alert-success">
    <?php echo e(session ('success_message')); ?>

  </div> -->
  <?php endif; ?>

  <div class="card shadow mb-4 w-50">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Form Master Indikator</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">
          <form method="POST" class="form-horizontal" action="<?php echo e(url('/admin/master_indikator')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label class="control-label col-sm-8" for="goal">Goal ke:</label>
              <div class="col-sm-4">
                <select class="form-control" name="goal">
                  <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_goals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($data_goals->id_goal); ?>">SDG <?php echo e($data_goals->id_goal); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="indikator">Indikator:</label>
              <div class="col-sm-10">
                <input name="indikator" type="text" class="form-control" id="indikator" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Tambahkan</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Table -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Tabel Indikator</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Goal</th>
              <th>Indikator</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $master_indikator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th><?php echo e($no); ?><?php $no++; ?></th>
              <th>SDG <?php echo e($data_master->fk_id_goal); ?></th>
              <th><?php echo e($data_master->indikator); ?></th>
              <th>
                <a href="<?php echo e(route('master_indikator.edit', $data_master->id_indikator)); ?>" class="btn btn-warning btn-circle btn-sm">
                  <i class="fas fa-edit"></i>
                </a> Ubah
                <form id="data-<?php echo e($data_master->id_indikator); ?>" action="<?php echo e(route('master_indikator.destroy',$data_master->id_indikator)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

                </form>
                <button class="btn btn-danger btn-circle btn-sm delete-confirm" type="submit" onclick="deleteRow( <?php echo e($data_master->id_indikator); ?> )">
                    <i class="fas fa-trash"></i>
                  </button> Hapus
              </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\admin\master_indikator.blade.php ENDPATH**/ ?>