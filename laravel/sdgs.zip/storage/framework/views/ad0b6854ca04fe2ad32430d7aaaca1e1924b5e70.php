<?php $__env->startSection('title','Profil'); ?>
<?php $__env->startSection('Judul','Profil'); ?>
<?php $__env->startSection('JudulDesc','Profil Admin'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb'); ?>
/ <a href="<?php echo e(url()->previous()); ?>"> Profil </a>
  <?php $__env->stopSection(); ?>

  <!-- Form -->
  <div class="card shadow mb-4 w-50">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Profil</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">


            <div class="form-group">
              <div class="col-sm-10">
                <div class="form-row">
                  <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                    <i class="fas fa-circle-notch prefix"></i>
                    <label>Nama</label>
                  </div>
                  <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                    <label>: <?php echo e($user->nama); ?></label>
                    <?php if($errors->has('nama')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('nama')); ?></strong>
                    </span>
                    <?php endif; ?>
                  </div>
                </div><br>

                <div class="form-row">
                  <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                    <i class="fas fa-circle-notch prefix"></i>
                    <label>Username</label>
                  </div>
                  <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                    <label>: <?php echo e($user->username); ?></label>
                    <?php if($errors->has('Username')): ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('Username')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                </div><br>

                <div class="form-row">
                  <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                    <i class="fas fa-circle-notch prefix"></i>
                    <label>NIP</label>
                  </div>
                  <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                    <label>: <?php echo e($user->nip); ?></label>
                    <?php if($errors->has('nip')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nip')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div><br>

                <div class="form-row">
                  <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                    <i class="fas fa-circle-notch prefix"></i>
                    <label>Jabatan</label>
                  </div>
                  <div class="col-sm-6 md-form amber-textarea active-amber-textarea">
                    <label>: <?php echo e($user->jabatan); ?></label>
                    <?php if($errors->has('jabatan')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('jabatan')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div><br>
              </div>
            </div>
            <hr><br>

            <!-- MODAL -->
            <div class="col-sm-10">
              <div class="form-row">

                <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                  <center>
                  <a href="<?php echo e(route('profil.edit', $user)); ?>" class="btn btn-primary pull-right" >Edit Profil</a>
                </center>
               
                </div>
              

                <div class="col-sm-5 md-form amber-textarea active-amber-textarea">
                  <center>
                  <a href="<?php echo e(route('password.edit')); ?>"class="btn btn-primary pull-right">Edit Password</a>
                </center>
                    </div>
                  </div>
                </div>
              </div><br>
            </div>

          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\admin\profil.blade.php ENDPATH**/ ?>