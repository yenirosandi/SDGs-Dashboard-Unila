<?php $__env->startSection('title', 'SDGs'); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
				<li class="breadcrumb-item active"  aria-current="page">Detail Goal <?php echo e($id); ?></a></li>
			</ol>
		</nav>

SUSTAINABLE DEVELOPMENT GOALS <hr>
      <!-- ***** Preloader Start ***** -->
      <div id="preloader">
        <div class="mosh-preloader"></div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $goal_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-xs-12">
            <div class-"thumbnail">
                <img src="/<?php echo e($goal->gambar); ?>" style="width:225px; height:225px;"class="card-img">
            </div>
        </div>
        <div class="col-md-8 col-md-offset-1">
            <h2><?php echo ucwords($goal->nama_goal); ?>
              </h2>
            <p style="text-align:justify; color:black"><?php echo e($goal->deskripsi_goal); ?> </p>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <br><br>
    <h4>Tabel</h4>


    <form action="<?php echo e(route('goaldetail.search', $goal->id_goal )); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="container">
                <div class="row">
                <label for="from" class="col-form-label">Dari</label>
                    <div class="col-md-3">
                            <select id="from" class="form-control"name="from" required>
                                      <option value="" >Pilih tahun</option>
                                        <?php
                                        $thn_skr=  date('Y');
                                        for ($tahun = $thn_skr; $tahun >= 2017; $tahun--) {
                                        ?>
                                        <option type="number"value="<?php echo e($tahun); ?>"><?php echo $tahun ?></option>
                                      <?php } ?>
                            </select>
                    </div>

                    <div class="col-md-4">
                       <!-- <button type="submit" class="btn btn-primary btn-sm" name="search" >Cari</button> -->
                        <button type="submit" class="btn btn-info btn-sm" name="exportPDF">Unduh PDF</button>
                    </div>

                </div>
            </div>
    </form>
		<label  style="margin-top:10px; font-size:12px; "> *Data dalam rentang waktu 5 tahun (Jika sudah diinputkan) </label>


    <br><br>

        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="auto" cellspacing="0">
            <thead>
              <tr>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">No.</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Indikator</th>
                <th style="text-align:center; vertical-align:middle;" rowspan="2">Sumber Data</th>
                <th style="text-align:center; vertical-align:middle;" colspan="2" rowspan="2">Baseline (2017)</th>
                <th style="text-align:center; vertical-align:middle;" colspan="<?php echo e($kolomtahun); ?>">Realisasi Pencapaian</th>
              </tr>
              <tr>
                <?php for($thn=2018; $thn <= $tahun_now; $thn++): ?>
                  <th colspan="2" style="text-align:center; vertical-align:middle;" ><?php echo e($thn); ?></th>
                <?php endfor; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <!-- <td style="text-align:center; vertical-align:middle;" colspan="6" disable>Belum ada data</td> -->
                  <?php if($data_sub->indikator->indikator!=$indikator): ?>
                    <th style="background-color:#e8f1ff; " colspan="<?php echo e($kolomindi); ?>"><?php echo e($data_sub->indikator->indikator); ?><a href="<?php echo e(route('grafik', $data_sub->indikator->id_indikator )); ?>"> (Grafik <span style="width:30px; height:30px"><img src="<?php echo e(url('img/statistics.png')); ?>" style="width:1.5%;" alt="">)</span></a></th>
                  <?php endif; ?>
                <?php $indikator=$data_sub->indikator->indikator; ?>
              </tr>
              <tr>
                <?php if($data_sub->subindikator!=$subindi): ?>
                  <td><?php echo e($no); ?></td>
                  <?php $no++; ?>

                  <td><?php echo e($data_sub->subindikator); ?></td>
                <?php else: ?><td style="background-color:#f5f5f5;" colspan="2"></td>
                <?php endif; ?>
                <?php $subindi=$data_sub->subindikator; ?>

                <?php if($data_sub->fk_id_indikator==$data_sub->indikator->id_indikator): ?>
                  <td><?php echo e($data_sub->fsumberdata->sumberdata); ?></td>
                <?php endif; ?>
                <!-- Buat nilai pencapaian -->


                <style>
                  td:empty{background:grey;} /* style css3 untuk kolom kosong */
                </style>


                <?php $__currentLoopData = $dcapai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_subs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php $tahun=2017; ?>
                  <?php while($tahun<=$tahun_now): ?>
                    <?php if($tahun==$data_subs->tahun && $data_sub->id_m_subindikator==$data_subs->fk_id_m_subindikator): ?>
                      <td><?php echo e($data_subs->nilai); ?></td>
                      <td>
                        <center>
                          <?php echo $data_subs->trend->simbol_trend; ?>

                        </center>
                      </td>

                      <?php elseif($data_subs->nilai==''): ?>
                      <td></td>
                      <td></td>
                    <?php endif; ?>
                    <?php $tahun++ ?>

                  <?php endwhile; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>



            </tbody>
          </table>
        </div>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\frontend\goal_detail.blade.php ENDPATH**/ ?>