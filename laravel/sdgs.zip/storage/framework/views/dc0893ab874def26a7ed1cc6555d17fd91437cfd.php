<?php $__env->startSection('title','Dashboard Admin'); ?>
<?php $__env->startSection('Judul','SDGs: Universitas Lampung'); ?>
<?php $__env->startSection('JudulDesc','Terdapat 11 SDGs yang harus diperhatikan dalam suatu universitas, diantaranya:'); ?>

<?php $__env->startSection('content'); ?>
  <h2>((Nanti dimunculkan sesuai database))</h2>
  <br>
  <div class="container">
    <table border="2">
      <tr>
        <img alt="">
        <td></td>
      </tr>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>