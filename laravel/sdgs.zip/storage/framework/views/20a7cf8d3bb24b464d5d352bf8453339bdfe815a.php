<?php $__env->startSection('title','Edit Master Sub-Indikator SDGs'); ?>
<?php $__env->startSection('Judul','Edit Master Sub-Indikator'); ?>
<?php $__env->startSection('JudulDesc','Ini adalah halaman edit master sub-indikator dimana terdapat form untuk memperbarui data master sub-indikator.'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb'); ?>
/ <a href="<?php echo e(url()->previous()); ?>">Sub Indikator</a>
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('title_breadcrumb2'); ?>
/ Edit Sub Indikator
<?php $__env->stopSection(); ?>

  
 <!-- Form -->
 <div class="card shadow mb-4 w-75">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Form Master Sub Indikator</h6>
    </div>
    <div class="card-body">
      <div class="card-body">
        <div class="table-responsive">
                                  <!--  -->
                                  <!-- <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?> -->
          <form method="post" class="form-horizontal" action="<?php echo e(route('master_sub_indikator.update',$edit_subindikators->id_m_subindikator)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('put')); ?>

            <div class="form-group">
            <label class="control-label col-sm-8" for="goal">Goal ke:</label>
              <div class="col-sm-4">
              <select id="slgoal" class="form-control" name="goal" data-urlreq="<?php echo e(route('get.list.capaian.indikator')); ?>">
              <option value="" >Pilih Goal</option>
              <?php $__currentLoopData = $fk_id_goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($key!=0){
                        $pencapaian_fk_goal=DB::table('t_goals')->select('id_goal','id_goal')->where('id_goal',$key)->get();
                        if(count($pencapaian_fk_goal)>0){
                            foreach ($pencapaian_fk_goal as $capai_indi){?>
                              <option value="<?php echo e($capai_indi->id_goal); ?>"<?php echo e($edit_fk_id_goals->id_goal==$capai_indi->id_goal?' selected':''); ?>>SDG <?php echo e($capai_indi->id_goal); ?></option>
                        <?php }
                      }
                    }
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="indikator">Indikator: </label>
              <div class="col-sm-10">
                 <select id="slindi" class="form-control" name="indikator" data-urlreq="<?php echo e(route('get.list.capaian.subindi')); ?>">
                  <?php $__currentLoopData = $fk_id_indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($value->id_indikator); ?>"<?php echo e($value->id_indikator==$edit_subindikators->fk_id_indikator?'selected':''); ?>> <?php echo e($value->indikator); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>   
            <div class="form-group">
              <label class="control-label col-sm-10" for="subindikator">Sub Indikator:</label>
              <div class="col-sm-10">
                <input value="<?php echo e($edit_subindikators->subindikator); ?>" name="subindikator" type="text" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="fk_id_m_sumberdata">Sumber Data: </label>
              <div class="col-sm-4">
                  <select name="fk_id_m_sumberdata" class="form-control">
                  <?php $__currentLoopData = $fk_sumberdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      if($key!=0){
                          $sub_fk_sumberdatas=DB::table('t_m_sumberdata')->select('id_m_sumberdata','sumberdata')->where('id_m_sumberdata',$key)->get();
                          if(count($sub_fk_sumberdatas)>0){
                              foreach ($sub_fk_sumberdatas as $sub_fk_sumberdata){?>
                                  <option value="<?php echo e($sub_fk_sumberdata->id_m_sumberdata); ?>"<?php echo e($edit_fk_sumberdatas->id_m_sumberdata==$sub_fk_sumberdata->id_m_sumberdata?' selected':''); ?>> <?php echo e($sub_fk_sumberdata->sumberdata); ?></option>
                          <?php }
                        }
                      }
                      ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-8" for="waktu_pengambilan">Waktu Pengambilan:</label>
              <div class="col-sm-6">
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Jan" <?php echo e(in_array("Jan", $waktu_pengambilan)? "checked":""); ?>>Jan
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Feb" <?php echo e(in_array("Feb", $waktu_pengambilan)? "checked":""); ?>>Feb
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Mar" <?php echo e(in_array("Mar", $waktu_pengambilan)? "checked":""); ?>>Mar
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Apr" <?php echo e(in_array("Apr", $waktu_pengambilan)? "checked":""); ?>>Apr
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Mei" <?php echo e(in_array("Mei", $waktu_pengambilan)? "checked":""); ?>>Mei
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Jun" <?php echo e(in_array("Jun", $waktu_pengambilan)? "checked":""); ?>>Jun
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Jul" <?php echo e(in_array("Jul", $waktu_pengambilan)? "checked":""); ?>>Jul
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Ags" <?php echo e(in_array("Ags", $waktu_pengambilan)? "checked":""); ?>>Ags
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Sep" <?php echo e(in_array("Sep", $waktu_pengambilan)? "checked":""); ?>>Sep
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Okt" <?php echo e(in_array("Okt", $waktu_pengambilan)? "checked":""); ?>>Okt
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Nov" <?php echo e(in_array("Nov", $waktu_pengambilan)? "checked":""); ?>>Nov
                </label>
                <label class="form-check-inline">
                  <input type="checkbox" name="waktu_pengambilan[]" value="Des" <?php echo e(in_array("Des", $waktu_pengambilan)? "checked":""); ?>>Des
                </label>
              </div>
            </div>
            <br>
            <div class="form-group">
              <label class="control-label col-sm-8" for="waktu_pengambilan">Jenis Isian:</label>
              <div class="col-sm-6">
                <label class="form-check-inline">        
              <?php if($edit_subindikators->isian == 'Angka'): ?>
                  <input type="radio" name="isian" value="Angka" checked> Angka<br>
                  <input type="radio" name="isian" value="Teks"> Teks
                <?php else: ?>
                <input type="radio" name="isian" value="Angka" > Angka<br>
                  <input type="radio" name="isian" value="Teks"checked> Teks
                <?php endif; ?>           
            </div>
            <br>
              <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Ubah</button>
              </div>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views\admin\master_sub_indikator_edit.blade.php ENDPATH**/ ?>