<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Sumber Data SDGs dari <?php echo e($sumberdata->sumberdata); ?></title>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/> -->
    <!-- ii<link rel="icon" href="http://zamisli2030.ba/wp-content/uploads/2018/11/sdg-no-bg.png"> -->
  </head>
  <body>
    <style type="text/css">
		  table tr td,
		  table tr th{
			  font-size: 14px;
        padding: 7px;
		  }
	  </style>
    <img src="http://sdgcenter.unila.ac.id/wp-content/uploads/2019/04/LOGO.png" width="20%">
    <br>
    <h4>SUMBER DATA: <?php echo e($sumberdata->sumberdata); ?></h4>
    Berikut adalah list data metrik SDGs untuk sumber data dari <?php echo e($sumberdata->sumberdata); ?>:
    <br><br>
      <table class="table table-bordered" border="1" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th style="text-align:center; vertical-align:middle;">Goal</th>
            <th style="text-align:center; vertical-align:middle;">Metrik</th>
            <th style="text-align:center; vertical-align:middle;">Indikator</th>
            <th style="text-align:center; vertical-align:middle;">Waktu Pengambilan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php if($data->id_goal!=$goal): ?>
            <td><?php echo e($data->id_goal); ?>: <?php echo e($data->nama_goal); ?></td>
            <?php else: ?><td style="background-color:#0000;"</td>
            <?php endif; ?>
            <?php $goal=$data->id_goal; ?>

            <?php if($data->indikator!=$indikator): ?>
            <td><?php echo e($data->indikator); ?></td>
            <?php else: ?><td style="background-color:#0000;"</td>
            <?php endif; ?>
            <?php $indikator=$data->indikator; ?>
 
            <td>(<?php echo e($no); ?>)<?php $no++; ?>
                <?php echo e($data->subindikator); ?></td>
            <td><?php echo e($data->waktu_pengambilan); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/layout/pdf.blade.php ENDPATH**/ ?>