<?php $__env->startSection('title','Form Pengajuan'); ?>
<?php $__env->startSection('Judul','Form Pengajuan'); ?>
<?php $__env->startSection('JudulDesc','Berikut adalah halaman untuk mengunduh berkas pengajuan data berdasarkan sumber data yang diinginkan'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title_breadcrumb','Unduh Form'); ?>

<div class="card shadow mb-4 w-75">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">List Pengajuan Form</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No.</th>
            <th>Sumber Data</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $sumberdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no); ?><?php $no++; ?></td>
            <td><?php echo e($data_sumber->sumberdata); ?></td>
            <td>
              <a href="<?php echo e(action('formPengajuanController@downloadPDF', $data_sumber->id_m_sumberdata)); ?>" class="btn btn-info btn-circle btn-sm">
                <i class="fas fa-file-download"></i>
              </a> Unduh
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SDGs-Dashboard-Unila\laravel\resources\views/admin/form_pengajuan.blade.php ENDPATH**/ ?>